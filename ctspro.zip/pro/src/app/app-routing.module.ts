import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageaccountComponent } from './manageaccount/manageaccount.component';
import { OpportunityComponent } from './opportunity/opportunity.component';

const routes: Routes = [

{
  path :'manageaccount',
  component:ManageaccountComponent
}
,
{
  path :'opportunity',
  component:OpportunityComponent
}
,
 {
  path :'',
  redirectTo :'/opportunity',
  pathMatch: 'full'
} 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const manageacc=[ManageaccountComponent , OpportunityComponent]