import { ChangeDetectionStrategy,Component, OnInit } from '@angular/core';
import {MatSnackBar} from '@angular/material';
export interface PeriodicElement {
  ServerName: string;
  Edit : String;
  Disable :String; 
}

const ELEMENT_DATA: PeriodicElement[] = [
  {ServerName :'S7OPS12',Edit:'Edit' , Disable:'Disable'},
  {ServerName :'DOPS12',Edit:'Edit' , Disable:'Disable'},
  {ServerName :'D8OPS12',Edit:'Edit' , Disable:'Disable'},
  {ServerName :'S3OPS12',Edit:'Edit' , Disable:'Disable'},
  {ServerName :'SOPS12',Edit:'Edit' , Disable:'Disable'},
  {ServerName :'UOPS12',Edit:'Edit' , Disable:'Disable'},
  {ServerName :'S4OPS12',Edit:'Edit' , Disable:'Disable'}
];
@Component({
  selector: 'app-manageaccount',
  templateUrl: 'manageaccount.component.html',
  styleUrls: ['manageaccount.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ManageaccountComponent implements OnInit {

  displayedColumns: string[] = ['ServerName']
  columnsToDisplay: string[] = this.displayedColumns.slice();
  data: PeriodicElement[] = ELEMENT_DATA;
  select : Boolean = true;
  addserver: Boolean = false;
  serverconfig: Boolean = true;
  updateserverconfig:Boolean=false;
  toggleField:String;
  
  constructor(public matsnackbar :MatSnackBar) {

  }
  ngOnInit() {
 
}
onSelectServer()
{
  this.updateserverconfig=false;
  this.addserver=false;
  if(this.serverconfig==false)
  {
    this.serverconfig=true;
  }
}
onAddServer()
{
  this.serverconfig=false;
  this.updateserverconfig=false;
  if(this.addserver==false)
  {
    this.addserver=true;

  }
}
onEditServer()
{
  this.serverconfig=false;
  this.addserver=false;
  if(this.updateserverconfig==false)
  {
    this.updateserverconfig=true;

  }
}
popsaveserver(savemessage:string,actions:string)
{
  this.matsnackbar.open(savemessage , actions, {
    duration: 10000,
  });
}
popupupdateserver(updatemessage:string,actions:string)
{
  this.matsnackbar.open(updatemessage,actions,{
      duration:10000,
  });
}
popupdisable(disablemessage:string,actions:string)
{
  this.matsnackbar.open(disablemessage,actions,{
    duration:10000,
  });
}
}
