import { Component, OnInit } from '@angular/core';
import {MatSnackBar} from '@angular/material';

@Component({
  selector: 'app-opportunity',
  templateUrl: './opportunity.component.html',
  styleUrls: ['./opportunity.component.scss']
})
export class OpportunityComponent implements OnInit {

  constructor(public matsnackbar:MatSnackBar) { }

  ngOnInit() {
  }

  popucreate(message:string,actions:string)
  {
      this.matsnackbar.open(message,actions,{
        duration : 10000,
      })
  }
}
